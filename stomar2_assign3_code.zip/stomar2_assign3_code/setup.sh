!wget https://github.com/sharvi24/Fine-grained-Entity-Typing/raw/main/training.zip
!unzip training.zip
!wget https://github.com/sharvi24/Fine-grained-Entity-Typing/raw/main/test.zip
!unzip test.zip
!wget https://github.com/sharvi24/Fine-grained-Entity-Typing/raw/main/lstm_fet.tar.gz
!tar -xvf /content/lstm_fet.tar.gz
!wget https://raw.githubusercontent.com/wilburOne/ACE_ERE_Scripts/master/ltf2sent.py
!git clone https://github.com/shahraj81/rufes.git
conda create --name rufes
conda activate rufes
conda install -c  pytorch
conda install -c  scikit-learn
pip install -U pandasql
