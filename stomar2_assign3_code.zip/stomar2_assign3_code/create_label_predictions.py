import numpy as np
import torch

from util import (load_word_embed,
                  get_label_vocab,
                  calculate_macro_fscore)

# train_file = 'rufes_train.json'
# dev_file = 'rufes_train.json'
# test_file = 'rufes_test.json'

train_file = 'data/en.dev.ds.json'
dev_file = 'rufes_test.json'
test_file = 'data/rufes_mentions_test.json'

label_vocab = get_label_vocab(train_file, dev_file, test_file)
print(label_vocab)
print(len(label_vocab))

# reversing
label_vocab = dict((v,k) for k,v in label_vocab.items())


all_predictions = torch.load('final_pred_file.pt', map_location=torch.device('cpu'))

labels = []
for i, prediction in enumerate(all_predictions):
    prediction = prediction.cpu().numpy()
    labels.append(
        [label_vocab[idx] for idx in list(np.nonzero(prediction == 1)[0])]
        )

with open('label_predictions.txt', 'w') as f:
    for label in labels:
        f.write(f"{label}\n")

