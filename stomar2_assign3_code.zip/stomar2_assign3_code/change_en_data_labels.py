import pandas as pd
import json

def level_find(df, label):
    if label in df['Level 3'].values.tolist():
        level1 = df.loc[df['Level 3']==label, 'Level 1'].item()
        level2 = df.loc[df['Level 3']==label, 'Level 2'].item()
        return [level1, f'{level1}.{level2}', f'{level1}.{level2}.{label}']
    elif label in df['Level 2'].values.tolist():
        level1 = df.loc[df['Level 2']==label, 'Level 1'].tolist()[0]
        return [level1, f'{level1}.{label}']
    else:
        return [None]

def change_labels(jsonfile, df):
    res = []
    with open(jsonfile, 'r') as r:
        for line in r:
            inst = json.loads(line)
            for i, _ in enumerate(inst['annotations']):
                inst['annotations'][i]['labels'] = [''.join([i for i in label if not i.isdigit()]) for label in inst['annotations'][i]['labels']]
                ret = set()
                for label in inst['annotations'][i]['labels']:
                    ret.update(level_find(df, label))
                if ret!={None}:
                    ret.discard(None)
                    inst['annotations'][i]['labels'] = list(ret)
                res.append(inst)
    
    with open(jsonfile, "w") as f:
        for line in res:
            json.dump(line, f)
            f.write('\n')

def main():
    df = pd.read_csv('data/ontology.csv')
    change_labels("data/en.dev.ds.json", df)
    # change_labels("data/en.train.ds.json", df)
    change_labels("data/en.test.ds.json", df)


if __name__ == '__main__':
    main()
