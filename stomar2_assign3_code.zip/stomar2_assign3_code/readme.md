## Assignment 3 - Fine-grained Entity Typing

### Setup
`setup.sh` contains the data download commands as well as the conda environment setup details.
To setup this assignment, please run `setup.sh`. To run this setup file, do:
```
./setup.sh
```

Alternatively, if you want to setup the env or look at how the env was setup refer below commands:
```
wget https://github.com/sharvi24/Fine-grained-Entity-Typing/raw/main/training.zip
unzip training.zip
wget https://github.com/sharvi24/Fine-grained-Entity-Typing/raw/main/test.zip
unzip test.zip
wget https://github.com/sharvi24/Fine-grained-Entity-Typing/raw/main/lstm_fet.tar.gz
tar -xvf /content/lstm_fet.tar.gz
wget https://raw.githubusercontent.com/wilburOne/ACE_ERE_Scripts/master/ltf2sent.py
git clone https://github.com/shahraj81/rufes.git

conda create --name rufes
conda activate rufes
conda install -c  pytorch
conda install -c  scikit-learn
pip install -U pandasql
```

### Run the experiment
The file `stomar2_code.py` runs the Fine-Grained Entity Typing sytem based on LSTM. The progressive loss values are printed out. 

After model's tuning for the specified epochs, the model's performance is tested on the test set. To run it please do:
```python stomar2_code.py``
